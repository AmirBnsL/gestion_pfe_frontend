



export default function ParticleBackground() {

  return (
    <div className="absolute inset-0 overflow-hidden">
   
        <div

          className="absolute rounded-full bg-white"

        />
      
    </div>
  )
}

